module.exports=[45450,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_config_route_actions_4f206dcd.js.map