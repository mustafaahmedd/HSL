module.exports=[13347,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_players_%5Bid%5D_route_actions_55d34c31.js.map