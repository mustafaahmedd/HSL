module.exports=[22506,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_events_page_actions_b938081b.js.map