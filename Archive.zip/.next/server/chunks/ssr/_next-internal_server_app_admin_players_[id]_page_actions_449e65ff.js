module.exports=[34228,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_players_%5Bid%5D_page_actions_449e65ff.js.map