module.exports=[6386,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_teams_page_actions_a7b9b18f.js.map