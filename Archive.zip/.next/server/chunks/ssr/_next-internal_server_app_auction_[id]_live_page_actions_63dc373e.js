module.exports=[48217,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auction_%5Bid%5D_live_page_actions_63dc373e.js.map