module.exports=[23299,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_players_page_actions_8e23aad4.js.map