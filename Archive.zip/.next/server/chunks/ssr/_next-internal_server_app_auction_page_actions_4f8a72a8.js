module.exports=[33333,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auction_page_actions_4f8a72a8.js.map