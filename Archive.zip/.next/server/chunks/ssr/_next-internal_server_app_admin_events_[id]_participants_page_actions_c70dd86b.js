module.exports=[72862,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_events_%5Bid%5D_participants_page_actions_c70dd86b.js.map