module.exports=[848,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_auction_page_actions_f818d561.js.map