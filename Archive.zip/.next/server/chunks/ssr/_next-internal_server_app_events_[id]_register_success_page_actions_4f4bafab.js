module.exports=[69979,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_events_%5Bid%5D_register_success_page_actions_4f4bafab.js.map