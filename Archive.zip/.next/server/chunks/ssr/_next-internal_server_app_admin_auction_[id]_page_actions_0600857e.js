module.exports=[88004,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_auction_%5Bid%5D_page_actions_0600857e.js.map