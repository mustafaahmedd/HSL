module.exports=[15993,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_register_page_actions_cf89a161.js.map