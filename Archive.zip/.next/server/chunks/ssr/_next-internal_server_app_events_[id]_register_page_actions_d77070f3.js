module.exports=[13782,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_events_%5Bid%5D_register_page_actions_d77070f3.js.map