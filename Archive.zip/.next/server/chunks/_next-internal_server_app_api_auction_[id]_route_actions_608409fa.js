module.exports=[30109,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auction_%5Bid%5D_route_actions_608409fa.js.map