module.exports=[48543,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_registrations_route_actions_d84e7724.js.map