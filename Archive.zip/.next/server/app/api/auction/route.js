var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/auction/route.js")
R.c("server/chunks/[root-of-the-server]__020597db._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__dcdeede3._.js")
R.c("server/chunks/_next-internal_server_app_api_auction_route_actions_f6198667.js")
R.m(19561)
module.exports=R.m(19561).exports
