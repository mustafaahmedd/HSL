var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/registrations/route.js")
R.c("server/chunks/[root-of-the-server]__87791481._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__dcdeede3._.js")
R.c("server/chunks/_next-internal_server_app_api_registrations_route_actions_d84e7724.js")
R.m(75452)
module.exports=R.m(75452).exports
