globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/bd599245817485f8.js",
    "static/chunks/112f346e31f991df.js",
    "static/chunks/aab5becddca52488.js",
    "static/chunks/58e77fc17acbf1e7.js",
    "static/chunks/2e5b89f46b61d738.js",
    "static/chunks/turbopack-d3fa78627f40a2ba.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];