(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_580d17e1._.js",
  "static/chunks/node_modules_next_dist_86f66277._.js"
],
    source: "dynamic"
});
