module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/mongoose [external] (mongoose, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("mongoose", () => require("mongoose"));

module.exports = mod;
}),
"[project]/src/lib/mongodb.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>dbConnect
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
    throw new Error("Please define the MONGODB_URI environment variable inside .env.local");
}
// Reuse connection across hot reloads in development
let cached = global.mongooseCache;
if (!cached) {
    cached = global.mongooseCache = {
        conn: null,
        promise: null
    };
}
async function dbConnect() {
    if (cached.conn) {
        // already connected
        return cached.conn;
    }
    if (!cached.promise) {
        const opts = {
            bufferCommands: false
        };
        // type-safe promise
        cached.promise = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].connect(MONGODB_URI, opts);
    }
    try {
        cached.conn = await cached.promise;
    } catch (err) {
        cached.promise = null;
        throw err;
    }
    return cached.conn;
}
}),
"[project]/src/models/Auction.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuctionSession",
    ()=>AuctionSession,
    "Bid",
    ()=>Bid,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
// Auction Schema
const AuctionSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"]({
    eventId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Event',
        required: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        trim: true
    },
    status: {
        type: String,
        enum: [
            'upcoming',
            'live',
            'completed',
            'cancelled'
        ],
        default: 'upcoming'
    },
    auctionDate: {
        type: Date,
        required: true
    },
    basePrice: {
        type: Number,
        required: true,
        default: 100
    },
    biddingIncrement: {
        type: Number,
        required: true,
        default: 50
    },
    timeLimitPerPlayer: {
        type: Number,
        required: true,
        default: 300
    },
    settings: {
        allowMultipleBids: {
            type: Boolean,
            default: true
        },
        autoAssignOnTimeout: {
            type: Boolean,
            default: false
        },
        requireMinimumBids: {
            type: Boolean,
            default: true
        },
        minimumBidsRequired: {
            type: Number,
            default: 1
        }
    },
    players: [
        {
            type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
            ref: 'Player'
        }
    ],
    teams: [
        {
            type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
            ref: 'Team'
        }
    ],
    totalRevenue: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true
});
// Bid Schema
const BidSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"]({
    auctionId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Auction',
        required: true
    },
    playerId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Player',
        required: true
    },
    teamId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Team',
        required: true
    },
    amount: {
        type: Number,
        required: true
    },
    timestamp: {
        type: Date,
        default: Date.now
    },
    isWinning: {
        type: Boolean,
        default: false
    },
    bidderInfo: {
        teamName: {
            type: String,
            required: true
        },
        ownerName: {
            type: String,
            required: true
        }
    }
}, {
    timestamps: true
});
// Auction Session Schema (for live auction management)
const AuctionSessionSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"]({
    auctionId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Auction',
        required: true,
        unique: true
    },
    currentPlayerId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Player'
    },
    biddingStartTime: {
        type: Date
    },
    biddingEndTime: {
        type: Date
    },
    currentHighestBid: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Bid'
    },
    biddingHistory: [
        {
            type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
            ref: 'Bid'
        }
    ],
    isActive: {
        type: Boolean,
        default: false
    },
    sessionStats: {
        totalPlayers: {
            type: Number,
            default: 0
        },
        playersSold: {
            type: Number,
            default: 0
        },
        playersRemaining: {
            type: Number,
            default: 0
        },
        totalRevenue: {
            type: Number,
            default: 0
        }
    }
}, {
    timestamps: true
});
// Indexes for efficient queries
AuctionSchema.index({
    eventId: 1,
    status: 1
});
AuctionSchema.index({
    auctionDate: 1
});
AuctionSchema.index({
    status: 1
});
BidSchema.index({
    auctionId: 1,
    playerId: 1
});
BidSchema.index({
    teamId: 1
});
BidSchema.index({
    timestamp: -1
});
BidSchema.index({
    isWinning: 1
});
AuctionSessionSchema.index({
    auctionId: 1
});
AuctionSessionSchema.index({
    isActive: 1
});
// Virtual for calculating remaining time
AuctionSessionSchema.virtual('timeRemaining').get(function() {
    if (!this.biddingEndTime || !this.isActive) return 0;
    const now = new Date();
    const remaining = this.biddingEndTime.getTime() - now.getTime();
    return Math.max(0, Math.floor(remaining / 1000));
});
// Pre-save middleware for auction
AuctionSchema.pre('save', function(next) {
    // Update total revenue when auction is completed
    if (this.status === 'completed') {
    // This will be calculated from bids
    }
    next();
});
// Pre-save middleware for bid
BidSchema.pre('save', function(next) {
    // Ensure only one winning bid per player
    if (this.isWinning) {
    // This will be handled in the API logic
    }
    next();
});
const Auction = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["models"].Auction || (0, __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["model"])('Auction', AuctionSchema);
const Bid = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["models"].Bid || (0, __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["model"])('Bid', BidSchema);
const AuctionSession = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["models"].AuctionSession || (0, __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["model"])('AuctionSession', AuctionSessionSchema);
const __TURBOPACK__default__export__ = Auction;
;
}),
"[project]/src/models/Event.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const EventSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"]({
    name: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true,
        trim: true
    },
    eventType: {
        type: String,
        enum: [
            'tournament',
            'activity',
            'event',
            'competition'
        ],
        required: true
    },
    status: {
        type: String,
        enum: [
            'upcoming',
            'live',
            'completed',
            'cancelled'
        ],
        default: 'upcoming'
    },
    startDate: {
        type: Date,
        required: true
    },
    endDate: {
        type: Date
    },
    venue: {
        type: String,
        required: true,
        trim: true
    },
    registrationType: {
        type: String,
        enum: [
            'individual',
            'team',
            'both'
        ],
        default: 'individual'
    },
    pricePerPerson: {
        type: Number,
        default: 0
    },
    pricePerTeam: {
        type: Number,
        default: 0
    },
    amenities: [
        {
            type: String,
            trim: true
        }
    ],
    facilities: [
        {
            type: String,
            trim: true
        }
    ],
    maxParticipants: {
        type: Number
    },
    minParticipants: {
        type: Number,
        default: 1
    },
    images: [
        {
            url: {
                type: String,
                required: true
            },
            caption: {
                type: String
            },
            isPrimary: {
                type: Boolean,
                default: false
            }
        }
    ],
    totalParticipants: {
        type: Number,
        default: 0
    },
    totalRevenue: {
        type: Number,
        default: 0
    },
    registrationDeadline: {
        type: Date
    },
    isPublished: {
        type: Boolean,
        default: true
    },
    tags: [
        {
            type: String,
            trim: true
        }
    ],
    organizer: {
        type: String,
        required: true,
        trim: true
    },
    contactInfo: {
        email: {
            type: String,
            trim: true
        },
        phone: {
            type: String,
            trim: true
        },
        whatsapp: {
            type: String,
            trim: true
        }
    }
}, {
    timestamps: true
});
// Indexes for efficient queries
EventSchema.index({
    status: 1,
    startDate: 1
});
EventSchema.index({
    eventType: 1
});
EventSchema.index({
    isPublished: 1
});
const Event = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["models"].Event || (0, __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["model"])('Event', EventSchema);
const __TURBOPACK__default__export__ = Event;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[project]/src/lib/auth.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateToken",
    ()=>generateToken,
    "getTokenFromRequest",
    ()=>getTokenFromRequest,
    "isAuthenticated",
    ()=>isAuthenticated,
    "validateAdmin",
    ()=>validateAdmin,
    "verifyToken",
    ()=>verifyToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jsonwebtoken/index.js [app-route] (ecmascript)");
;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
function generateToken(payload) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].sign(payload, JWT_SECRET, {
        expiresIn: '24h'
    });
}
function verifyToken(token) {
    try {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].verify(token, JWT_SECRET);
    } catch (error) {
        return null;
    }
}
async function validateAdmin(username, password) {
    return username === ADMIN_USERNAME && password === ADMIN_PASSWORD;
}
function getTokenFromRequest(request) {
    const authHeader = request.headers.get('authorization');
    if (!authHeader) return null;
    const [bearer, token] = authHeader.split(' ');
    if (bearer !== 'Bearer') return null;
    return token;
}
async function isAuthenticated(request) {
    const token = getTokenFromRequest(request);
    if (!token) return false;
    const payload = verifyToken(token);
    return payload !== null && payload.role === 'admin';
}
}),
"[project]/src/app/api/auction/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DELETE",
    ()=>DELETE,
    "GET",
    ()=>GET,
    "POST",
    ()=>POST,
    "PUT",
    ()=>PUT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/mongodb.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Auction$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/models/Auction.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Event$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/models/Event.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth.ts [app-route] (ecmascript)");
;
;
;
;
;
async function GET(request) {
    try {
        const isAuth = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isAuthenticated"])(request);
        if (!isAuth) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Unauthorized'
            }, {
                status: 401
            });
        }
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])();
        const { searchParams } = new URL(request.url);
        const eventId = searchParams.get('eventId');
        const status = searchParams.get('status');
        let query = {};
        if (eventId) query.eventId = eventId;
        if (status) query.status = status;
        const auctions = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Auction$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].find(query).populate('eventId', 'name description').populate('players', 'name type category status').populate('teams', 'name owner totalBudget pointsSpent pointsLeft').sort({
            auctionDate: -1
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            auctions
        });
    } catch (error) {
        console.error('Error fetching auctions:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Failed to fetch auctions'
        }, {
            status: 500
        });
    }
}
async function POST(request) {
    try {
        const isAuth = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isAuthenticated"])(request);
        if (!isAuth) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Unauthorized'
            }, {
                status: 401
            });
        }
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])();
        const body = await request.json();
        const { eventId, name, description, auctionDate, basePrice, biddingIncrement, timeLimitPerPlayer, settings } = body;
        // Validate required fields
        if (!eventId || !name || !auctionDate) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Missing required fields'
            }, {
                status: 400
            });
        }
        // Check if event exists
        const event = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Event$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].findById(eventId);
        if (!event) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Event not found'
            }, {
                status: 404
            });
        }
        const auction = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Auction$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"]({
            eventId,
            name,
            description,
            auctionDate: new Date(auctionDate),
            basePrice: basePrice || 100,
            biddingIncrement: biddingIncrement || 50,
            timeLimitPerPlayer: timeLimitPerPlayer || 300,
            settings: {
                allowMultipleBids: settings?.allowMultipleBids ?? true,
                autoAssignOnTimeout: settings?.autoAssignOnTimeout ?? false,
                requireMinimumBids: settings?.requireMinimumBids ?? true,
                minimumBidsRequired: settings?.minimumBidsRequired ?? 1
            },
            players: [],
            teams: [],
            totalRevenue: 0
        });
        await auction.save();
        // Create auction session
        const session = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Auction$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AuctionSession"]({
            auctionId: auction._id,
            isActive: false,
            sessionStats: {
                totalPlayers: 0,
                playersSold: 0,
                playersRemaining: 0,
                totalRevenue: 0
            }
        });
        await session.save();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            auction,
            message: 'Auction created successfully'
        });
    } catch (error) {
        console.error('Error creating auction:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Failed to create auction'
        }, {
            status: 500
        });
    }
}
async function PUT(request) {
    try {
        const isAuth = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isAuthenticated"])(request);
        if (!isAuth) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Unauthorized'
            }, {
                status: 401
            });
        }
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])();
        const body = await request.json();
        const { auctionId, updates } = body;
        if (!auctionId) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Auction ID is required'
            }, {
                status: 400
            });
        }
        const auction = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Auction$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].findByIdAndUpdate(auctionId, {
            ...updates,
            updatedAt: new Date()
        }, {
            new: true
        }).populate('eventId', 'name description').populate('players', 'name type category status').populate('teams', 'name owner totalBudget pointsSpent pointsLeft');
        if (!auction) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Auction not found'
            }, {
                status: 404
            });
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            auction,
            message: 'Auction updated successfully'
        });
    } catch (error) {
        console.error('Error updating auction:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Failed to update auction'
        }, {
            status: 500
        });
    }
}
async function DELETE(request) {
    try {
        const isAuth = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isAuthenticated"])(request);
        if (!isAuth) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Unauthorized'
            }, {
                status: 401
            });
        }
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])();
        const { searchParams } = new URL(request.url);
        const auctionId = searchParams.get('auctionId');
        if (!auctionId) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Auction ID is required'
            }, {
                status: 400
            });
        }
        // Check if auction exists and is not live
        const auction = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Auction$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].findById(auctionId);
        if (!auction) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Auction not found'
            }, {
                status: 404
            });
        }
        if (auction.status === 'live') {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Cannot delete live auction'
            }, {
                status: 400
            });
        }
        // Delete related bids and session
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Auction$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Bid"].deleteMany({
            auctionId
        });
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Auction$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AuctionSession"].deleteOne({
            auctionId
        });
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Auction$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].findByIdAndDelete(auctionId);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            message: 'Auction deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting auction:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Failed to delete auction'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b0cbe05a._.js.map