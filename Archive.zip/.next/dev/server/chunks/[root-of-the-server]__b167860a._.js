module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/mongoose [external] (mongoose, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("mongoose", () => require("mongoose"));

module.exports = mod;
}),
"[project]/src/lib/mongodb.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>dbConnect
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
    throw new Error("Please define the MONGODB_URI environment variable inside .env.local");
}
// Reuse connection across hot reloads in development
let cached = global.mongooseCache;
if (!cached) {
    cached = global.mongooseCache = {
        conn: null,
        promise: null
    };
}
async function dbConnect() {
    if (cached.conn) {
        // already connected
        return cached.conn;
    }
    if (!cached.promise) {
        const opts = {
            bufferCommands: false
        };
        // type-safe promise
        cached.promise = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].connect(MONGODB_URI, opts);
    }
    try {
        cached.conn = await cached.promise;
    } catch (err) {
        cached.promise = null;
        throw err;
    }
    return cached.conn;
}
}),
"[project]/src/models/Player.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const PlayerSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"]({
    // Registration Form Fields
    name: {
        type: String,
        required: true,
        trim: true
    },
    contactNo: {
        type: String,
        required: true,
        trim: true
    },
    isHikmahStudent: {
        type: Boolean,
        required: true
    },
    courseEnrolled: {
        type: String,
        trim: true
    },
    darseNizamiYear: {
        type: String,
        trim: true
    },
    currentCourseYear: {
        type: String,
        trim: true
    },
    timings: {
        type: String,
        required: true
    },
    playBothTournaments: {
        type: Boolean,
        required: true
    },
    skillLevel: {
        type: String,
        required: true
    },
    iconPlayerRequest: {
        type: Boolean,
        required: true
    },
    selfAssignedCategory: {
        type: String,
        required: true
    },
    photoUrl: {
        type: String,
        required: true
    },
    // Admin Override Fields
    type: {
        type: String,
        enum: [
            'Batsman',
            'Bowler',
            'Batting All-Rounder',
            'Bowling All-Rounder'
        ]
    },
    category: {
        type: String,
        enum: [
            'Platinum',
            'Diamond',
            'Gold',
            'Silver',
            'Bronze'
        ]
    },
    // Auction Related Fields
    status: {
        type: String,
        enum: [
            'available',
            'sold'
        ],
        default: 'available'
    },
    teamId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Team'
    },
    role: {
        type: String,
        enum: [
            'Player',
            'Captain'
        ],
        default: 'Player'
    },
    bidPrice: {
        type: Number
    }
}, {
    timestamps: true
});
// Index for efficient queries
PlayerSchema.index({
    status: 1,
    category: 1
});
PlayerSchema.index({
    teamId: 1
});
const Player = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["models"].Player || (0, __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["model"])('Player', PlayerSchema);
const __TURBOPACK__default__export__ = Player;
}),
"[project]/src/models/Registration.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const RegistrationSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"]({
    eventId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Event',
        required: true
    },
    eventName: {
        type: String,
        required: true,
        trim: true
    },
    playerId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Player',
        required: true
    },
    // Personal Information (stored in both Player and Registration for easy access)
    name: {
        type: String,
        required: true,
        trim: true
    },
    contactNo: {
        type: String,
        required: true,
        trim: true
    },
    isHikmahStudent: {
        type: Boolean,
        required: true
    },
    courseEnrolled: {
        type: String,
        trim: true
    },
    darseNizamiYear: {
        type: String,
        trim: true
    },
    currentCourseYear: {
        type: String,
        trim: true
    },
    timings: {
        type: String,
        required: true,
        trim: true
    },
    photoUrl: {
        type: String,
        trim: true
    },
    // Sport-specific details
    specialRequirements: {
        type: String,
        trim: true
    },
    teamName: {
        type: String,
        trim: true
    },
    playBothTournaments: {
        type: Boolean,
        default: false
    },
    skillLevel: {
        type: String,
        trim: true
    },
    iconPlayerRequest: {
        type: Boolean,
        default: false
    },
    selfAssignedCategory: {
        type: String,
        trim: true
    },
    type: {
        type: String,
        trim: true
    },
    position: {
        type: String,
        trim: true
    },
    experience: {
        type: String,
        trim: true
    },
    level: {
        type: String,
        trim: true
    },
    // Registration details
    paymentMethod: {
        type: String,
        trim: true
    },
    paymentStatus: {
        type: String,
        enum: [
            'pending',
            'paid',
            'failed',
            'refunded'
        ],
        default: 'pending'
    },
    amountPaid: {
        type: Number,
        default: 0
    },
    assurance: {
        type: Boolean,
        default: false
    },
    // Status
    status: {
        type: String,
        enum: [
            'pending',
            'approved',
            'rejected',
            'cancelled'
        ],
        default: 'pending'
    },
    registrationDate: {
        type: Date,
        default: Date.now
    },
    // Admin Management
    adminNotes: {
        type: String,
        trim: true
    },
    finalizedDetails: {
        finalName: {
            type: String,
            trim: true
        },
        finalEmail: {
            type: String,
            trim: true
        },
        finalPhone: {
            type: String,
            trim: true
        },
        finalTeamName: {
            type: String,
            trim: true
        }
    },
    approvedBy: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'User'
    },
    approvedAt: {
        type: Date
    },
    rejectionReason: {
        type: String,
        trim: true
    }
}, {
    timestamps: true
});
// Indexes for efficient queries
RegistrationSchema.index({
    eventId: 1,
    status: 1
});
RegistrationSchema.index({
    playerId: 1
});
RegistrationSchema.index({
    registrationDate: -1
});
RegistrationSchema.index({
    status: 1
});
const Registration = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["models"].Registration || (0, __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["model"])('Registration', RegistrationSchema);
const __TURBOPACK__default__export__ = Registration;
}),
"[project]/src/models/Event.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const EventSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"]({
    title: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true,
        trim: true
    },
    eventType: {
        type: String,
        enum: [
            'tournament',
            'activity',
            'event',
            'competition'
        ],
        required: true
    },
    sport: {
        type: String,
        enum: [
            'cricket',
            'football',
            'futsal',
            'cycling',
            'padel',
            'badminton',
            'tennis',
            'basketball',
            'volleyball',
            'swimming',
            'athletics',
            'academic'
        ],
        default: 'cricket'
    },
    status: {
        type: String,
        enum: [
            'upcoming',
            'live',
            'completed',
            'cancelled'
        ],
        default: 'upcoming'
    },
    startDate: {
        type: Date,
        required: true
    },
    startTime: {
        type: String,
        required: true
    },
    endTime: {
        type: String,
        required: true
    },
    venue: {
        type: String,
        required: true,
        trim: true
    },
    registrationType: {
        type: String,
        enum: [
            'individual',
            'team',
            'both'
        ],
        default: 'individual'
    },
    pricePerPerson: {
        type: Number,
        default: 0
    },
    pricePerTeam: {
        type: Number,
        default: 0
    },
    amenities: [
        {
            type: String,
            trim: true
        }
    ],
    facilities: [
        {
            type: String,
            trim: true
        }
    ],
    maxParticipants: {
        type: Number
    },
    minParticipants: {
        type: Number,
        default: 1
    },
    images: [
        {
            url: {
                type: String,
                required: true
            },
            caption: {
                type: String
            },
            isPrimary: {
                type: Boolean,
                default: false
            }
        }
    ],
    totalParticipants: {
        type: Number,
        default: 0
    },
    totalRevenue: {
        type: Number,
        default: 0
    },
    registrationDeadline: {
        type: Date
    },
    isPublished: {
        type: Boolean,
        default: true
    },
    tags: [
        {
            type: String,
            trim: true
        }
    ],
    organizer: {
        type: String,
        required: true,
        trim: true
    },
    contactInfo: {
        phone: {
            type: String,
            trim: true
        }
    }
}, {
    timestamps: true
});
// Indexes for efficient queries
EventSchema.index({
    status: 1,
    startDate: 1
});
EventSchema.index({
    eventType: 1
});
EventSchema.index({
    isPublished: 1
});
const Event = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["models"].Event || (0, __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["model"])('Event', EventSchema);
const __TURBOPACK__default__export__ = Event;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[project]/src/lib/upload.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteFile",
    ()=>deleteFile,
    "deleteFileByUrl",
    ()=>deleteFileByUrl,
    "ensureDirectoryExists",
    ()=>ensureDirectoryExists,
    "extractFiles",
    ()=>extractFiles,
    "generateFilename",
    ()=>generateFilename,
    "saveFile",
    ()=>saveFile,
    "saveFiles",
    ()=>saveFiles,
    "validateFile",
    ()=>validateFile
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
;
;
// Default configuration
const DEFAULT_CONFIG = {
    maxFileSize: 5 * 1024 * 1024,
    allowedTypes: [
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/gif',
        'image/svg',
        'image/webp'
    ],
    category: 'general'
};
function validateFile(file, config = {}) {
    const { maxFileSize = DEFAULT_CONFIG.maxFileSize, allowedTypes = DEFAULT_CONFIG.allowedTypes } = config;
    // Check file size
    if (file.size > maxFileSize) {
        return {
            valid: false,
            error: `File size exceeds ${maxFileSize / (1024 * 1024)}MB limit`
        };
    }
    // Check file type
    if (!allowedTypes.includes(file.type)) {
        return {
            valid: false,
            error: 'Only image files are allowed (jpg, jpeg, png, gif, svg, webp)'
        };
    }
    return {
        valid: true
    };
}
function generateFilename(originalName, category) {
    const timestamp = Date.now();
    const extension = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].extname(originalName);
    return `${category}_${timestamp}${extension}`;
}
function ensureDirectoryExists(dirPath) {
    if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(dirPath)) {
        __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].mkdirSync(dirPath, {
            recursive: true
        });
    }
}
async function saveFile(file, category = 'general', config = {}) {
    const { maxFileSize = DEFAULT_CONFIG.maxFileSize } = config;
    // Validate file
    const validation = validateFile(file, {
        maxFileSize,
        allowedTypes: config.allowedTypes
    });
    if (!validation.valid) {
        throw new Error(validation.error);
    }
    // Generate filename and path
    const filename = generateFilename(file.name, category);
    const uploadDir = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'public', 'uploads', category);
    const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(uploadDir, filename);
    // Ensure directory exists
    ensureDirectoryExists(uploadDir);
    // Convert File to Buffer and save
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].writeFileSync(filePath, buffer);
    return {
        originalName: file.name,
        filename,
        path: filePath,
        url: `/uploads/${category}/${filename}`,
        size: file.size,
        mimetype: file.type
    };
}
async function saveFiles(files, category = 'general', config = {}) {
    const results = [];
    for (const file of files){
        if (file.size > 0) {
            try {
                const result = await saveFile(file, category, config);
                results.push(result);
            } catch (error) {
                console.error(`Failed to save file ${file.name}:`, error);
                throw error;
            }
        }
    }
    return results;
}
function extractFiles(formData, fieldName) {
    const files = [];
    // Handle single file
    const singleFile = formData.get(fieldName);
    if (singleFile && singleFile.size > 0) {
        files.push(singleFile);
    }
    // Handle multiple files
    const multipleFiles = formData.getAll(fieldName);
    for (const file of multipleFiles){
        if (file && file.size > 0 && !files.some((f)=>f.name === file.name && f.size === file.size)) {
            files.push(file);
        }
    }
    return files;
}
function deleteFile(filePath) {
    try {
        if (__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(filePath)) {
            __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].unlinkSync(filePath);
            return true;
        }
        return false;
    } catch (error) {
        console.error('Failed to delete file:', error);
        return false;
    }
}
function deleteFileByUrl(url) {
    try {
        const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'public', url);
        return deleteFile(filePath);
    } catch (error) {
        console.error('Failed to delete file by URL:', error);
        return false;
    }
}
}),
"[project]/src/app/api/register/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/mongodb.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Player$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/models/Player.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Registration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/models/Registration.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Event$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/models/Event.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$upload$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/upload.ts [app-route] (ecmascript)");
;
;
;
;
;
;
;
async function POST(request) {
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])();
        const formData = await request.formData();
        // Extract all form fields
        const formFields = {
            // Event related
            eventId: formData.get('eventId'),
            // Personal details (for Player collection)
            name: formData.get('name'),
            contactNo: formData.get('contactNo'),
            isHikmahStudent: formData.get('isHikmahStudent') === 'true',
            courseEnrolled: formData.get('courseEnrolled') || undefined,
            darseNizamiYear: formData.get('darseNizamiYear') || undefined,
            currentCourseYear: formData.get('currentCourseYear') || undefined,
            timings: formData.get('timings'),
            // Sport specific details (for Registration collection)
            playBothTournaments: formData.get('playBothTournaments') === 'true',
            skillLevel: formData.get('skillLevel'),
            iconPlayerRequest: formData.get('iconPlayerRequest') === 'true',
            selfAssignedCategory: formData.get('selfAssignedCategory'),
            type: formData.get('type') || undefined,
            position: formData.get('position') || undefined,
            experience: formData.get('experience') || undefined,
            subject: formData.get('subject') || undefined,
            level: formData.get('level') || undefined,
            category: formData.get('category') || undefined,
            // Additional fields
            teamName: formData.get('teamName') || undefined,
            specialRequirements: formData.get('specialRequirements') || undefined,
            teamMembers: formData.get('teamMembers') || undefined,
            department: formData.get('department') || undefined,
            phone: formData.get('phone') || undefined,
            // Registration details
            paymentMethod: formData.get('paymentMethod'),
            assurance: formData.get('assurance') === 'true'
        };
        // Check if event exists first
        const event = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Event$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].findById(formFields.eventId);
        if (!event) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Event not found'
            }, {
                status: 404
            });
        }
        // Validate required fields (make validation more flexible based on sport type)
        const requiredFields = [
            'eventId',
            'name',
            'contactNo',
            'timings',
            'skillLevel',
            'paymentMethod'
        ];
        // Add sport-specific required fields
        if (event.sport === 'cricket') {
            requiredFields.push('selfAssignedCategory');
        }
        for (const field of requiredFields){
            if (!formFields[field]) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    error: `${field} is required`
                }, {
                    status: 400
                });
            }
        }
        // Step 1: Find or create player based on name + contactNo
        let player = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Player$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].findOne({
            name: formFields.name,
            contactNo: formFields.contactNo
        });
        if (!player) {
            // Create new player with personal details
            const playerData = {
                name: formFields.name,
                contactNo: formFields.contactNo,
                isHikmahStudent: formFields.isHikmahStudent,
                courseEnrolled: formFields.courseEnrolled,
                darseNizamiYear: formFields.darseNizamiYear,
                currentCourseYear: formFields.currentCourseYear,
                timings: formFields.timings
            };
            // Handle photo upload
            const photoFile = formData.get('photo');
            if (photoFile && photoFile.size > 0) {
                try {
                    const uploadedFile = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$upload$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["saveFile"])(photoFile, 'players');
                    playerData.photoUrl = uploadedFile.url;
                } catch (error) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        error: `Photo upload failed: ${error.message}`
                    }, {
                        status: 400
                    });
                }
            } else {
                playerData.photoUrl = '/placeholder.jpg';
            }
            player = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Player$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].create(playerData);
        }
        // Step 2: Create registration with event-specific data
        const registrationData = {
            eventId: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Types"].ObjectId(formFields.eventId),
            eventName: event.title,
            playerId: player._id,
            // Personal Information (duplicated for easy access)
            name: formFields.name,
            contactNo: formFields.contactNo,
            isHikmahStudent: formFields.isHikmahStudent,
            courseEnrolled: formFields.courseEnrolled,
            darseNizamiYear: formFields.darseNizamiYear,
            currentCourseYear: formFields.currentCourseYear,
            timings: formFields.timings,
            // Sport-specific details
            playBothTournaments: formFields.playBothTournaments,
            skillLevel: formFields.skillLevel,
            iconPlayerRequest: formFields.iconPlayerRequest,
            selfAssignedCategory: formFields.selfAssignedCategory,
            type: formFields.type,
            position: formFields.position,
            experience: formFields.experience,
            level: formFields.level,
            // Additional fields
            teamName: formFields.teamName,
            specialRequirements: formFields.specialRequirements,
            // Registration details
            paymentMethod: formFields.paymentMethod,
            assurance: formFields.assurance,
            status: 'pending',
            registrationDate: new Date()
        };
        // Handle photo for registration (use the same photo as player)
        if (player.photoUrl) {
            registrationData.photoUrl = player.photoUrl;
        }
        const registration = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Registration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].create(registrationData);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            message: 'Registration successful',
            registration: {
                id: registration._id,
                playerId: player._id,
                eventId: formFields.eventId,
                status: registration.status
            }
        });
    } catch (error) {
        console.error('Registration error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to register player'
        }, {
            status: 500
        });
    }
}
async function GET(request) {
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])();
        const players = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Player$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].find({}).sort({
            createdAt: -1
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            players
        });
    } catch (error) {
        console.error('Get players error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to fetch players'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b167860a._.js.map