module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/mongoose [external] (mongoose, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("mongoose", () => require("mongoose"));

module.exports = mod;
}),
"[project]/src/lib/mongodb.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>dbConnect
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
    throw new Error("Please define the MONGODB_URI environment variable inside .env.local");
}
// Reuse connection across hot reloads in development
let cached = global.mongooseCache;
if (!cached) {
    cached = global.mongooseCache = {
        conn: null,
        promise: null
    };
}
async function dbConnect() {
    if (cached.conn) {
        // already connected
        return cached.conn;
    }
    if (!cached.promise) {
        const opts = {
            bufferCommands: false
        };
        // type-safe promise
        cached.promise = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["default"].connect(MONGODB_URI, opts);
    }
    try {
        cached.conn = await cached.promise;
    } catch (err) {
        cached.promise = null;
        throw err;
    }
    return cached.conn;
}
}),
"[project]/src/models/Player.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const PlayerSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"]({
    // Registration Form Fields
    name: {
        type: String,
        required: true,
        trim: true
    },
    contactNo: {
        type: String,
        required: true,
        trim: true
    },
    isHikmahStudent: {
        type: Boolean,
        required: true
    },
    courseEnrolled: {
        type: String,
        trim: true
    },
    darseNizamiYear: {
        type: String,
        trim: true
    },
    currentCourseYear: {
        type: String,
        trim: true
    },
    timings: {
        type: String,
        required: true
    },
    playBothTournaments: {
        type: Boolean,
        required: true
    },
    skillLevel: {
        type: String,
        required: true
    },
    iconPlayerRequest: {
        type: Boolean,
        required: true
    },
    selfAssignedCategory: {
        type: String,
        required: true
    },
    photoUrl: {
        type: String,
        required: true
    },
    // Admin Override Fields
    type: {
        type: String,
        enum: [
            'Batsman',
            'Bowler',
            'Batting All-Rounder',
            'Bowling All-Rounder'
        ]
    },
    category: {
        type: String,
        enum: [
            'Platinum',
            'Diamond',
            'Gold',
            'Silver',
            'Bronze'
        ]
    },
    // Auction Related Fields
    status: {
        type: String,
        enum: [
            'available',
            'sold'
        ],
        default: 'available'
    },
    teamId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Team'
    },
    role: {
        type: String,
        enum: [
            'Player',
            'Captain'
        ],
        default: 'Player'
    },
    bidPrice: {
        type: Number
    }
}, {
    timestamps: true
});
// Index for efficient queries
PlayerSchema.index({
    status: 1,
    category: 1
});
PlayerSchema.index({
    teamId: 1
});
const Player = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["models"].Player || (0, __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["model"])('Player', PlayerSchema);
const __TURBOPACK__default__export__ = Player;
}),
"[project]/src/models/Registration.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const RegistrationSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"]({
    eventId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Event',
        required: true
    },
    eventName: {
        type: String,
        required: true,
        trim: true
    },
    eventType: {
        type: String,
        enum: [
            'tournament',
            'activity',
            'event',
            'competition'
        ],
        required: true
    },
    registrationType: {
        type: String,
        enum: [
            'individual',
            'team',
            'both'
        ],
        required: true
    },
    // Personal Information
    name: {
        type: String,
        required: true,
        trim: true
    },
    phone: {
        type: String,
        required: true,
        trim: true
    },
    // Team Information
    teamName: {
        type: String,
        trim: true
    },
    teamMembers: [
        {
            type: String,
            trim: true
        }
    ],
    // Registration Details
    registrationDate: {
        type: Date,
        default: Date.now
    },
    status: {
        type: String,
        enum: [
            'pending',
            'approved',
            'rejected',
            'cancelled'
        ],
        default: 'pending'
    },
    paymentStatus: {
        type: String,
        enum: [
            'pending',
            'paid',
            'refunded'
        ],
        default: 'pending'
    },
    amountPaid: {
        type: Number,
        default: 0
    },
    // Additional Information
    specialRequirements: {
        type: String,
        trim: true
    },
    notes: {
        type: String,
        trim: true
    },
    // Admin Management Fields
    adminNotes: {
        type: String,
        trim: true
    },
    finalizedDetails: {
        finalName: {
            type: String,
            trim: true
        },
        finalEmail: {
            type: String,
            trim: true
        },
        finalPhone: {
            type: String,
            trim: true
        },
        finalStudentId: {
            type: String,
            trim: true
        },
        finalDepartment: {
            type: String,
            trim: true
        },
        finalEmergencyContact: {
            type: String,
            trim: true
        },
        finalTeamName: {
            type: String,
            trim: true
        },
        finalTeamMembers: [
            {
                type: String,
                trim: true
            }
        ],
        finalSpecialRequirements: {
            type: String,
            trim: true
        }
    },
    // Player Reference
    playerId: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'Player'
    },
    // Admin Management
    approvedBy: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"].Types.ObjectId,
        ref: 'User'
    },
    approvedAt: {
        type: Date
    },
    rejectionReason: {
        type: String,
        trim: true
    }
}, {
    timestamps: true
});
// Indexes for efficient queries
RegistrationSchema.index({
    eventId: 1,
    status: 1
});
RegistrationSchema.index({
    email: 1
});
RegistrationSchema.index({
    studentId: 1
});
RegistrationSchema.index({
    registrationDate: -1
});
RegistrationSchema.index({
    status: 1
});
const Registration = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["models"].Registration || (0, __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["model"])('Registration', RegistrationSchema);
const __TURBOPACK__default__export__ = Registration;
}),
"[project]/src/models/Event.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs)");
;
const EventSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["Schema"]({
    name: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true,
        trim: true
    },
    eventType: {
        type: String,
        enum: [
            'tournament',
            'activity',
            'event',
            'competition'
        ],
        required: true
    },
    sport: {
        type: String,
        enum: [
            'cricket',
            'football',
            'futsal',
            'cycling',
            'padel',
            'badminton',
            'tennis',
            'basketball',
            'volleyball',
            'swimming',
            'athletics',
            'academic'
        ],
        default: 'cricket'
    },
    status: {
        type: String,
        enum: [
            'upcoming',
            'live',
            'completed',
            'cancelled'
        ],
        default: 'upcoming'
    },
    startDate: {
        type: Date,
        required: true
    },
    startTime: {
        type: String,
        required: true
    },
    endTime: {
        type: String,
        required: true
    },
    venue: {
        type: String,
        required: true,
        trim: true
    },
    registrationType: {
        type: String,
        enum: [
            'individual',
            'team',
            'both'
        ],
        default: 'individual'
    },
    pricePerPerson: {
        type: Number,
        default: 0
    },
    pricePerTeam: {
        type: Number,
        default: 0
    },
    amenities: [
        {
            type: String,
            trim: true
        }
    ],
    facilities: [
        {
            type: String,
            trim: true
        }
    ],
    maxParticipants: {
        type: Number
    },
    minParticipants: {
        type: Number,
        default: 1
    },
    images: [
        {
            url: {
                type: String,
                required: true
            },
            caption: {
                type: String
            },
            isPrimary: {
                type: Boolean,
                default: false
            }
        }
    ],
    totalParticipants: {
        type: Number,
        default: 0
    },
    totalRevenue: {
        type: Number,
        default: 0
    },
    registrationDeadline: {
        type: Date
    },
    isPublished: {
        type: Boolean,
        default: true
    },
    tags: [
        {
            type: String,
            trim: true
        }
    ],
    organizer: {
        type: String,
        required: true,
        trim: true
    },
    contactInfo: {
        email: {
            type: String,
            trim: true
        },
        phone: {
            type: String,
            trim: true
        },
        whatsapp: {
            type: String,
            trim: true
        }
    }
}, {
    timestamps: true
});
// Indexes for efficient queries
EventSchema.index({
    status: 1,
    startDate: 1
});
EventSchema.index({
    eventType: 1
});
EventSchema.index({
    isPublished: 1
});
const Event = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["models"].Event || (0, __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$29$__["model"])('Event', EventSchema);
const __TURBOPACK__default__export__ = Event;
}),
"[project]/src/app/api/register/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/mongodb.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Player$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/models/Player.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Registration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/models/Registration.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Event$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/models/Event.ts [app-route] (ecmascript)");
;
;
;
;
;
async function POST(request) {
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])();
        const formData = await request.formData();
        // Extract all form fields
        const formFields = {
            // Event related
            eventId: formData.get('eventId'),
            // Personal details (for Player collection)
            name: formData.get('name'),
            contactNo: formData.get('contactNo'),
            isHikmahStudent: formData.get('isHikmahStudent') === 'true',
            courseEnrolled: formData.get('courseEnrolled') || undefined,
            darseNizamiYear: formData.get('darseNizamiYear') || undefined,
            currentCourseYear: formData.get('currentCourseYear') || undefined,
            timings: formData.get('timings'),
            // Sport specific details (for Registration collection)
            playBothTournaments: formData.get('playBothTournaments') === 'true',
            skillLevel: formData.get('skillLevel'),
            iconPlayerRequest: formData.get('iconPlayerRequest') === 'true',
            selfAssignedCategory: formData.get('selfAssignedCategory'),
            type: formData.get('type') || undefined,
            position: formData.get('position') || undefined,
            experience: formData.get('experience') || undefined,
            subject: formData.get('subject') || undefined,
            level: formData.get('level') || undefined,
            // Registration details
            paymentMethod: formData.get('paymentMethod'),
            assurance: formData.get('assurance') === 'true'
        };
        // Validate required fields
        const requiredFields = [
            'eventId',
            'name',
            'contactNo',
            'timings',
            'skillLevel',
            'selfAssignedCategory',
            'paymentMethod'
        ];
        for (const field of requiredFields){
            if (!formFields[field]) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    error: `${field} is required`
                }, {
                    status: 400
                });
            }
        }
        // Check if event exists
        const event = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Event$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].findById(formFields.eventId);
        if (!event) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Event not found'
            }, {
                status: 404
            });
        }
        // Step 1: Find or create player based on name + contactNo
        let player = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Player$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].findOne({
            name: formFields.name,
            contactNo: formFields.contactNo
        });
        if (!player) {
            // Create new player with personal details
            const playerData = {
                name: formFields.name,
                contactNo: formFields.contactNo,
                isHikmahStudent: formFields.isHikmahStudent,
                courseEnrolled: formFields.courseEnrolled,
                darseNizamiYear: formFields.darseNizamiYear,
                currentCourseYear: formFields.currentCourseYear,
                timings: formFields.timings
            };
            // Handle photo upload
            const photoFile = formData.get('photo');
            if (photoFile && photoFile.size > 0) {
                const fileName = `player-${Date.now()}-${photoFile.name}`;
                playerData.photoUrl = `/uploads/players/${fileName}`;
            } else {
                playerData.photoUrl = '/placeholder.jpg';
            }
            player = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Player$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].create(playerData);
        }
        // Step 2: Create registration with event-specific data
        const registrationData = {
            event: formFields.eventId,
            player: player._id,
            playBothTournaments: formFields.playBothTournaments,
            skillLevel: formFields.skillLevel,
            iconPlayerRequest: formFields.iconPlayerRequest,
            selfAssignedCategory: formFields.selfAssignedCategory,
            type: formFields.type,
            position: formFields.position,
            experience: formFields.experience,
            subject: formFields.subject,
            level: formFields.level,
            paymentMethod: formFields.paymentMethod,
            assurance: formFields.assurance,
            status: 'pending',
            registrationDate: new Date()
        };
        // Handle photo for registration (if different from player photo)
        const registrationPhotoFile = formData.get('photo');
        if (registrationPhotoFile && registrationPhotoFile.size > 0) {
            const fileName = `registration-${Date.now()}-${registrationPhotoFile.name}`;
            registrationData.photoUrl = `/uploads/registrations/${fileName}`;
        }
        const registration = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Registration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].create(registrationData);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            message: 'Registration successful',
            registration: {
                id: registration._id,
                playerId: player._id,
                eventId: formFields.eventId,
                status: registration.status
            }
        });
    } catch (error) {
        console.error('Registration error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to register player'
        }, {
            status: 500
        });
    }
}
async function GET(request) {
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$mongodb$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])();
        const players = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$models$2f$Player$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].find({}).sort({
            createdAt: -1
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            players
        });
    } catch (error) {
        console.error('Get players error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to fetch players'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b598d45e._.js.map