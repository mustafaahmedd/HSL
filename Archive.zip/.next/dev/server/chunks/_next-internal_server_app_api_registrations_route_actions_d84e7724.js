module.exports = [
"[project]/.next-internal/server/app/api/registrations/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_registrations_route_actions_d84e7724.js.map