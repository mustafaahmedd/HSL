module.exports = [
"[project]/.next-internal/server/app/admin/events/[id]/participants/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_events_%5Bid%5D_participants_page_actions_c70dd86b.js.map