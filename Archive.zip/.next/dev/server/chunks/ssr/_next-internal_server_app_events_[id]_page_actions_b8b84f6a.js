module.exports = [
"[project]/.next-internal/server/app/events/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_events_%5Bid%5D_page_actions_b8b84f6a.js.map