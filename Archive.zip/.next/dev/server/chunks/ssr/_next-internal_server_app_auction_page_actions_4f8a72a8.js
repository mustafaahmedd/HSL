module.exports = [
"[project]/.next-internal/server/app/auction/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_auction_page_actions_4f8a72a8.js.map