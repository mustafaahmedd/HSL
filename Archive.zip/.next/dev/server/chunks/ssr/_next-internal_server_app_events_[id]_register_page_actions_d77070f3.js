module.exports = [
"[project]/.next-internal/server/app/events/[id]/register/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_events_%5Bid%5D_register_page_actions_d77070f3.js.map