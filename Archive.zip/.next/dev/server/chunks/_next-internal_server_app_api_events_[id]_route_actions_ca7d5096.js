module.exports = [
"[project]/.next-internal/server/app/api/events/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_events_%5Bid%5D_route_actions_ca7d5096.js.map